# PHASE 0 — INDEX & STATUS

**Phase 0 (STUDY_PLAN_TwoPapers.md §6, weeks 1–3):** pre-register the Ngram + Trends protocols on OSF; write lexicons/codebooks; build gold sets.

**Status:** documents drafted and frozen at v1.0 (2026-08-09). **The OSF upload itself is manual and pending — see OSF_Checklist.md.** Nothing may be pulled or analyzed until the registrations exist.

## Files in this folder

| File | Status | Purpose |
|---|---|---|
| `PREREG_Study1_Ngram_H1.md` | FROZEN v1.0 | Study 1 (H1 supply side): Ngram relative-share, log-odds, crossover, acceleration, robustness, H1f sense-validation rule, falsification, limitations, deviations log |
| `PREREG_Study2_Trends_H1.md` | FROZEN v1.0 | Study 2 (H1 demand side): Trends chained-scaling protocol, noise protocol, D_t divergence, breakpoint windows, state-level correlations, robustness, falsification |
| `LEXICONS_Codebook.md` | §1–§2 FROZEN; §3–§4 draft | 20-term Ngram lexicon + 9 Trends queries with sense definitions and ambiguity flags; H2 relief/truth lexicons (draft); H6/H5/H4 codebook skeletons (draft) |
| `GOLD_SET_Plan.md` | Procedure fixed | GS-1 sense validation (Phase 0, mandatory before Ngram analysis); GS-2/3/4 scheduled for later phases; dual-coder rules |
| `OSF_Checklist.md` | Ready to execute | Step-by-step manual OSF registration (two registrations, OSF Preregistration template, no embargo), field mapping table, status tracker |

## Key technical findings locked during Phase 0 (2026-08-09)

1. **Ngram JSON API ignores sub-corpus codes** — verified empirically: `corpus=eng_fiction_2019` and `eng_nonfiction_2019` return the same series as `eng-2019`. Consequence: the genre split (H1d) must use the raw v3 datasets (20200217), not the API. This is documented inside the frozen protocol (§3.1–3.2).
2. **Ngram API returns relative frequencies only** (no raw counts) — fine: frequencies share one denominator (total 1-grams per corpus-year), so summing across terms of mixed n-gram length is valid.
3. **Case-insensitive searches return the aggregated `(All)` series** — used as the analysis series.
4. **Trends 5-term limit** → chained scaling with anchor `prayer` (sensitivity anchor `church`), median-of-5 pulls (protocol §3.2–3.3).

## Blocking items (need the human)

1. OSF account → registrations (OSF_Checklist.md, ~45 min).
2. Second human rater for GS-1 dual-coding (README §10.5).

## Not in Phase 0 (do not start yet)

- Any Ngram/Trends data pull or analysis (Phase 1, after registrations exist).
- H2/H5/H6/H4/H8 data work (phases 2–5).
