# GOLD SET PLAN — Phase 0 + future phases

**Status:** GS-1 (sense validation) is part of the Phase 0 registration family and must be built before any Ngram analysis runs. GS-2…GS-4 are scheduled for their phases; the *procedure* below is fixed now, the *content* is frozen per phase.

**The sister-project rule (README §8, §10.5):** every annotation needs TWO human coders and a kappa report. Single-annotator gold sets were the root of months of problems in the sister project. No exception.

---

## GS-1 — Ngram term-sense validation (Phase 0, ~1,000 snippets)

- **Purpose:** estimate sense-precision of each of the 20 Ngram lexicon terms (LEXICONS_Codebook §1); feed the H1f flag rule (precision < 0.70 → flag, reduced-lexicon rerun).
- **Sampling:** per term, up to 50 short book snippets containing the term via the Google Books API (q="{term}", `langRestrict=en`, first 50 unique snippets; re-weight to include up to 25 pre-1950 snippets if available).
- **Coding scheme:** TARGET (intended sense) / OFF (different sense) / AMBIG (indeterminate).
- **Coders:** two independent humans, blind; disagreements adjudicated by a third.
- **Metric:** precision = TARGET/(TARGET + OFF); AMBIG excluded. κ ≥ 0.70 required before precision is computed.
- **Timing rule:** built and results archived in the OSF project BEFORE any Ngram analysis (Study 1 registration §6.5).
- **Products:** `gold_set_gs1_snippets.csv` (anonymized), `gold_set_gs1_labels_raters.csv`, `gold_set_gs1_summary.csv` (per-term precision, κ, flag list).

## GS-2 — H2 relief/truth narrative gold set (Phase 2, 150 docs)

- **Purpose:** validate the relief-vs-truth annotation for deconversion narratives (Study 3).
- **Sampling:** 150 documents — ~100 YouTube deconversion-transcript excerpts ("I left the church" testimonies across ex-Christian / ex-Muslim / ex-Hindu / ex-Mormon channels) + ~50 memoir/blog excerpts (public domain + Wayback Machine). Stratified by tradition.
- **Coding scheme:** primary frame per document (relief / truth / mixed / other); time-course tags (relief/truth language before vs after the narrative's switch point); ex-Muslim apostasy-fear flag.
- **Coders:** two humans; κ ≥ 0.70; adjudication by third. LLM-as-judge (3-model majority, `--safe-mode`, neutral directory) is run AFTER the gold set is locked, never before.
- **Fallback (pre-registered in STUDY_PLAN H2):** if < 100 usable docs after cleaning, Study 3 is dropped from the discovery paper and H2 becomes literature-only.

## GS-3 — H6 religious-skeleton codebook set (Phase 3, 30 excerpts)

- 30 excerpts: 15 self-help (5 public-domain classics — Carnegie, Peale, Wattles, Dale + 1 more — and 10 fair-use excerpts from NYT-best-seller lists) × 15 scripture (KJV, Gita, Dhammapada).
- One κ per codebook feature (8 features, LEXICONS_Codebook §4.1); feature-level κ ≥ 0.70.

## GS-4 — H5/H4 code sets (Phase 4)

- H5: 40 influencer transcripts (20 predicted-extraction-heavy, 20 predicted-delivery-heavy — sampled blind to scores) × extraction/delivery markers; κ per marker.
- H4: 150 YouTube transcripts × blame-locus (individualizing/systemicizing); κ ≥ 0.70, then LLM-as-judge scale-up.

---

## RATER LOGISTICS (all gold sets)

1. **Recruitment:** second human rater — README §10.5 decision stands; start outreach during Phase 1 (rater needs overlap with GS-2 timeline).
2. **Blinding:** coders never see each other's labels; adjudicator sees both, never the analysis results.
3. **Order of operations:** codebook freeze → gold-set sample → independent coding → κ → adjudication → precision/use → analyses. Never the reverse.
4. **Storage:** all gold sets live in the OSF project (`gold_sets/`), with version hashes recorded in the deviation logs of the relevant registrations.
5. **In the papers:** kappa tables and per-feature precision go in the methods appendix; a one-line statement "all annotations were dual-coded" in the main text.
