# OSF CHECKLIST — Registering the Ngram + Trends protocols

**Goal:** two time-stamped, DOI'd, immutable pre-registrations on the Open Science Framework, frozen BEFORE any data pull. Everything below is manual (no API automation required); ~45 minutes once the two protocol files are final.

**Prerequisite:** PREREG_Study1_Ngram_H1.md and PREREG_Study2_Trends_H1.md are frozen at v1.0. Do not register until you are done editing them (post-registration edits are possible only as dated deviation-log entries).

---

## Step 0 — Account

1. Go to https://osf.io and sign up (free) / log in.

## Step 1 — Project scaffolding

2. Create a project: name `Religion Metamorphosis: The Neo-Religion of the Self`; public; license CC-By-4.0; add author(s).
3. Create components inside the project:
   - `Pre-registrations` (contains the two registrations below)
   - `Data and gold sets` (raw Ngram JSON cache, Trends CSVs, gold-set files — added AFTER registration)
   - `Analysis code` (retrieval + analysis scripts with git hashes)
   - `Papers` (drafts)

## Step 2 — Registration 1: Study 1 (Ngram)

4. Open the `Pre-registrations` component → **Registrations** tab → **New registration**.
5. Template: **OSF Preregistration** (the standard, comprehensive, most commonly used form; verified current). The *Secondary Data Preregistration* template is an acceptable alternative since Ngram is existing data — the general template is recommended because it asks for the analysis detail this study already specifies.
6. Title: `Study 1 — The Great Host Switch: Ngram cultural-prominence test (H1, supply side)`
7. Fill the form fields — copy from PREREG_Study1_Ngram_H1.md (§→field mapping in Step 4 table).
8. Upload files: `PREREG_Study1_Ngram_H1.md`, `LEXICONS_Codebook.md`, `GOLD_SET_Plan.md`.
9. Embargo: **none (public immediately)** — recommended: stronger credibility, and the project has no publication-timing secret at this stage. (If you later want secrecy, 24-month embargo is available, but decide now; changing later is not possible.)
10. Contributors: add the second rater as a contributor when known (can also be added to the project later).
11. Submit → wait for DOI (minutes–hours). Record: registration URL + DOI → paste into `PREREG_Study1_Ngram_H1.md` header and README.md §10.

## Step 3 — Registration 2: Study 2 (Trends)

12. Repeat steps 4–11 for Study 2:
    - Template: OSF Preregistration.
    - Title: `Study 2 — The Great Host Switch: Google Trends divergence test (H1, demand side)`
    - Files: `PREREG_Study2_Trends_H1.md`, `LEXICONS_Codebook.md`.
    - Embargo: none.
    - Record URL + DOI → paste into `PREREG_Study2_Trends_H1.md` header and README.md §10.

## Step 4 — Field mapping (both registrations; OSF Preregistration template)

| OSF field | Where the answer lives |
|---|---|
| Study title / authors | Protocol header + OSF metadata |
| Study type | "Secondary data analysis of publicly available archives (Google Books Ngram / Google Trends)" |
| Hypotheses | Protocol §2 (copy the hypothesis letter and text verbatim) |
| Data collection / sampling plan | Protocol §3 (data source, parameters, rate-limit protocol, chained scaling for Trends, noise protocol) |
| Variables | Lexicon §1/§2 lists; metrics defined in protocol §2.1 (S_t, R_t, L_t, A_t, B_t, D_t) |
| Analysis plan | Protocol §5 (exact order: series construction → primary slope → crossover/breakpoints → robustness variants; α = 0.05, one-sided; HAC SEs; Mann–Kendall robustness) |
| Falsification criteria | Protocol §6 verbatim |
| Deviations | Leave "none planned"; the protocol's own §10 log will record any that occur |

## Step 5 — After registration (still Phase 0)

13. Build **GS-1 gold set** (GOLD_SET_Plan.md): sample snippets, dual-code, compute κ and precision, archive results in `Data and gold sets` component. This is pre-registered (procedure is inside the frozen registration), so it may be done after the timestamp.
14. Write the retrieval scripts (Phase 1 start) — commit to the OSF project with git hash; the hash belongs in the registration wiki as a comment (addenda are visible and timestamped without breaking immutability).
15. Then, and only then: pull Ngram data and run the analyses in protocol §5 order.

## Step 6 — Discipline notes

- Never run any analysis from protocol §5 before the registration DOI exists. A registration made after data collection is a *postregistration* and does not carry pre-registration's evidential weight.
- The registrations freeze only the plans + lexicon; the gold-set *results*, the raw data, and the scripts live in the project (editable, versioned) — that is the standard OSF split.
- Any deviation → dated entry in the protocol's §10 table AND a comment on the registration wiki. Reviewers see the log, not a surprise.

## Status tracker

- [ ] OSF account created
- [ ] Project + components created
- [ ] Registration 1 (Ngram) submitted, DOI recorded
- [ ] Registration 2 (Trends) submitted, DOI recorded
- [ ] DOIs pasted into protocol headers + README §10
- [ ] GS-1 gold set built, kappa ≥ 0.70, results archived
- [ ] Retrieval scripts committed to project
